%%%% -------------------------
%%%% install_MEIGO
%%%% -------------------------
%
% install_MEIGO adds the MEIGO toolbox files to the Matlab path.

pwd_ssm=pwd;
addpath(genpath(pwd_ssm))

disp('  ')
disp('  >>>>>>>> MEIGO has been added to the Matlab path <<<<<<<<')
disp('  ')